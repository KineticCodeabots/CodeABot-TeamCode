package org.firstinspires.ftc.teamcode.LearningJavaCode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.LearningJavaCode.Mechanisms.TestBenchMotorCode;

@TeleOp

public class DCMotorPractise extends OpMode {
    TestBenchMotorCode bench = new TestBenchMotorCode();
    @Override
    public void init() {
        bench.init(hardwareMap);
    }

    @Override
    public void loop() {
        double motorSpeed = gamepad1.left_stick_y;
        bench.setMotorspeed(motorSpeed);
        telemetry.addData("motor Revs", bench.getMotorRevs());
    }
}
