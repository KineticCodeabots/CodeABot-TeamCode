package org.firstinspires.ftc.teamcode.LearningJavaCode;

public class RobotLocationPractise {
    double angle;
    double x;
    double y;

    // constructor method
    public RobotLocationPractise(double angle) {
        this.angle = angle;
    }

    public double getHeading() {
        //this method normalizes robot heading between -180 and 180 degrees
        // this is useful for calculating turn angles especially when crossing the 0,360 boundery


        double angle = this.angle; //copy the angle of the imy
        while (angle > 180) {
            angle -= 360; // subtract until in taget range.
        }
        while (angle <= -180) {
            angle += 360; // add until in target range
        }
        return angle;// returns angle normalized value


    }
    public void turnRobot(double angleChange) {
        angle += angleChange;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }

    public double getAngle() {
        return this.angle;
    }
    public void changex(double changeAmount){
        x += changeAmount;
    }
    public void setX(double x) {
        this.x = x;
    }
    public double getX() {
        return this.x;
    }
    public void changeY(double changeAmountY) {
        y += changeAmountY;
    }
    public void setY(double y) {
        this.y = y;
    }
    public double getY() {
        return this.y;
    }
}
