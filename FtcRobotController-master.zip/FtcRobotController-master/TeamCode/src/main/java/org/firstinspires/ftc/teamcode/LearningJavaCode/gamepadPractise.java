package org.firstinspires.ftc.teamcode.LearningJavaCode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@TeleOp
@Disabled
public class gamepadPractise extends OpMode {
    @Override
    public void init() {


    }

    @Override
    public void loop() {

        Double speedForwardLy = -gamepad1.left_stick_y / 2.0;
        Double speedForwardLx = gamepad1.left_stick_x / 2.0;
        Double speedForwardRx = gamepad1.right_stick_x / 2.0;
        Double speedForwardRy = gamepad1.right_stick_y / 2.0;
        Double DifferenceBetweenLxAndRx = speedForwardLx - speedForwardRx;
        Double RT = gamepad1.right_trigger / 2.0;
        Double LT = gamepad1.left_trigger / 2.0;
        Double SumOfLTandRT = RT + LT;

telemetry.addData("Lx", speedForwardLx);
telemetry.addData("Ly", speedForwardLy);
telemetry.addData("Rx", speedForwardRx);
telemetry.addData("Ry", speedForwardRy);
telemetry.addData("A button", gamepad1.a);
telemetry.addData("B button", gamepad1.b);
telemetry.addData("Difference Between Lx And Rx", DifferenceBetweenLxAndRx);
telemetry.addData("Sum of LT + RT", SumOfLTandRT);
    }
}
