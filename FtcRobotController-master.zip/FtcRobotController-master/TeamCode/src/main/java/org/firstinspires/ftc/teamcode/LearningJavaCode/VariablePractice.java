package org.firstinspires.ftc.teamcode.LearningJavaCode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
@Disabled

@TeleOp
public class VariablePractice extends OpMode {
    @Override
    public void init() {
        int teamNumber = 23389;
        double motorSpeed = 0.8;
        boolean clawClosed = true;
        String TeamName = "Kinetic CodeABots 23389";
        int MotorAngle = 60;
        telemetry.addData("team number", teamNumber);
        telemetry.addData("Motor Speed", motorSpeed);
        telemetry.addData("Is Claw closed", clawClosed);
        telemetry.addData("Team", TeamName);
        telemetry.addData("Motor Angle", MotorAngle);


    }

    @Override
    public void loop() {

    }
}
