package org.firstinspires.ftc.teamcode.MilesCode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.teamcode.LearningJavaCode.BackroundCodeDrivetrain;


public class MecanumDrivetrainMainCode extends OpMode {
    BackroundCodeDrivetrain drive = new BackroundCodeDrivetrain();

    double forward, strafe, rotate;

    @Override
    public void init(){
        drive.init(hardwareMap);
    }

    public void loop(){
        forward = gamepad1.left_stick_y;
        strafe = gamepad1.left_stick_x;
        rotate = gamepad1.right_stick_x;

        drive.driveFieldRelative(forward, strafe, rotate);
    }
}
