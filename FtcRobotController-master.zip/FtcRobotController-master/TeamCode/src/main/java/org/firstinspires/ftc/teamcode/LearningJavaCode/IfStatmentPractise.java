package org.firstinspires.ftc.teamcode.LearningJavaCode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
@TeleOp
@Disabled
public class IfStatmentPractise extends OpMode {
    @Override

    public void init() {

    }

    @Override
    public void loop() {
        double LeftY = -gamepad1.left_stick_y;
        double MotorSpeed = LeftY;
        boolean aButton = gamepad1.a;

        if (LeftY < 0.1 && LeftY > -0.1) {
            telemetry.addData("LeftStick", "in dead zone");
        }
        if (!aButton){
            telemetry.addData("motor speed", MotorSpeed / 2);
        }
        else if (aButton){
            telemetry.addData("motor speed", MotorSpeed);
        }



        telemetry.addData("Left Stick Value", LeftY);
    }
}
/*
And = && Example if (LeftY < 0.5 && LeftY > 0) {
Or = || Example if (LeftY < 0 || RightY < 0) {
Not = ! Example if (!clawClosed) {
 */